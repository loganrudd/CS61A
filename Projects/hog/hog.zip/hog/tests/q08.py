test = {
  'names': [
    'q08',
    'q8',
    '8'
  ],
  'points': 1,
  'suites': [
    [
      {
        'locked': True,
        'test': """
        >>> bacon_strategy(0, 0)
        ff608b607dd57d4aed39affea70b8a33
        # locked
        """,
        'type': 'doctest'
      },
      {
        'locked': True,
        'test': """
        >>> bacon_strategy(70, 50)
        ff608b607dd57d4aed39affea70b8a33
        # locked
        """,
        'type': 'doctest'
      },
      {
        'locked': True,
        'test': """
        >>> bacon_strategy(50, 70)
        99c13236f272a6aaef23abd340164ca1
        # locked
        """,
        'type': 'doctest'
      },
      {
        'locked': True,
        'test': """
        >>> bacon_strategy(32, 4, 5, 4)
        99c13236f272a6aaef23abd340164ca1
        # locked
        """,
        'type': 'doctest'
      },
      {
        'locked': True,
        'test': """
        >>> bacon_strategy(20, 25, 5, 4)
        1d91a458ef35b7c8a5c7ed9cff3e3a74
        # locked
        """,
        'type': 'doctest'
      }
    ]
  ]
}