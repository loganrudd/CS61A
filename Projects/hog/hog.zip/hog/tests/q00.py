test = {
  'names': [
    'q00',
    '0',
    'q0'
  ],
  'points': 0,
  'suites': [
    [
      {
        'locked': True,
        'test': """
        >>> test_dice = make_test_dice(4, 1, 2)
        >>> test_dice()
        1d91a458ef35b7c8a5c7ed9cff3e3a74
        # locked
        >>> test_dice() # Second call
        7b2c79174a8474e2d2f0088168095436
        # locked
        >>> test_dice() # Third call
        2b8e487f61dd9ec748d5f4b50f317793
        # locked
        >>> test_dice() # Fourth call
        1d91a458ef35b7c8a5c7ed9cff3e3a74
        # locked
        """,
        'type': 'doctest'
      }
    ]
  ]
}