info = {
  'hash_key': 'lc5445ls29oabn4at2c50j3nuwdfxtujicxum9kp4qvvebvhmh1pgpzf1e1xtba2087b0sa4hoz28wkq5ks2agwge1kqit0ln097gn9rqrhs3a87r5h2gh8t4qa8k41w',
  'name': 'proj1',
  'params': {
    'doctest': {
      'cache': """
      import hog
      from hog import *
      """
    }
  },
  'src_files': [
    'hog.py'
  ],
  'version': '1.0'
}