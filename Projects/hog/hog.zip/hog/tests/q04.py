test = {
  'names': [
    'q04',
    '4',
    'q4'
  ],
  'points': 1,
  'suites': [
    [
      {
        'locked': True,
        'test': """
        >>> score0, score1, start = bid_for_start(1, 1, goal=100) # start can be 0 or 1
        >>> score0
        216ba8f036c509de88cf8910dd464e20
        # locked
        >>> score1
        216ba8f036c509de88cf8910dd464e20
        # locked
        """,
        'type': 'doctest'
      },
      {
        'locked': True,
        'test': """
        >>> score0, score1, start = bid_for_start(2, 7, goal=100)
        >>> score0
        99c13236f272a6aaef23abd340164ca1
        # locked
        >>> score1
        f83d9dab1c8937437fd7ae066e2ecb66
        # locked
        >>> start
        7b2c79174a8474e2d2f0088168095436
        # locked
        """,
        'type': 'doctest'
      },
      {
        'locked': True,
        'test': """
        >>> score0, score1, start = bid_for_start(8, 3, goal=100)
        >>> score0
        f83d9dab1c8937437fd7ae066e2ecb66
        # locked
        >>> score1
        99c13236f272a6aaef23abd340164ca1
        # locked
        >>> start
        99c13236f272a6aaef23abd340164ca1
        # locked
        """,
        'type': 'doctest'
      },
      {
        'locked': True,
        'test': """
        >>> score0, score1, start = bid_for_start(4, 3, goal=100)
        >>> score0
        5b262897a6e71ea548719bfcad14222e
        # locked
        >>> score1
        1d91a458ef35b7c8a5c7ed9cff3e3a74
        # locked
        >>> start
        99c13236f272a6aaef23abd340164ca1
        # locked
        """,
        'type': 'doctest'
      },
      {
        'locked': True,
        'test': """
        >>> score0, score1, start = bid_for_start(3, 4, goal=100)
        >>> score0
        1d91a458ef35b7c8a5c7ed9cff3e3a74
        # locked
        >>> score1
        5b262897a6e71ea548719bfcad14222e
        # locked
        >>> start
        7b2c79174a8474e2d2f0088168095436
        # locked
        """,
        'type': 'doctest'
      }
    ]
  ]
}